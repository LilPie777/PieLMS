# Main Powershell file for PieCore Module
Write-Output "***********************************************************"
Write-Output "Welcome to PieCore!"
Write-Output "***********************************************************"

