<?php
echo $_POST["sclusn"]; 
?>