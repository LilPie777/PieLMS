<nav class="navbar navbar-light navbar-custom">
  <div class="container">
  <img src="resources/Main-Logo.png" alt="" width="200" height="50" class="d-inline-block">
    <h2>Welcome to the School of Pienance</h2>
  </div>
</nav>