<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/b870970ad8.js" crossorigin="anonymous"></script>
     <!-- Current styles for home page -->
    <style>
        <?php include __DIR__ . "/modules/themes/pie-styles.css"; ?>
        .b-ma-contentBlock1
        {
            color: red;
        }
    </style>
    <?php include __DIR__ . "/modules/themes/header.php"; ?>
</head>
<body>
    <main class = "b-ma-content">
        <div class="container b-ma-contentBlock1">
        <div class="row">
            <div class="col">
                <h2>Welcome<h2>              
            </div>
    </div>
    </div>
</main>
</body>
</html>